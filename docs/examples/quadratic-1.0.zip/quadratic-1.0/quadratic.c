/*
 * quadratic.c
 *
 * Author: Oscar Benjamin
 * Date: 30th Jan 2017
 * Description:
 *     This is our first attempt at making
 *     a program that will compute the
 *     roots of quadratic polynomials.
 */

#include <stdio.h>

int isqrt(int);
void print_rational(int num, int denom);
void print_quadratic(int a, int b, int c);

int main(int argc, char *argv[])
{
    int a = 1;
    int b = 5;
    int c = 6;

    /* Show the quadratic we're showing for the user */
    printf("The roots of ");
    print_quadratic(a, b, c);
    printf(" are:\n");

    /* Calculate the disciminant and its square root */
    int discriminant = b*b - 4*a*c;
    int sqrtd = isqrt(discriminant);

    /* Check to see if the sqrt is exact */
    if(sqrtd * sqrtd == discriminant)
    {
        print_rational(-b + sqrtd, 2*a);
        printf("\n");
        print_rational(-b - sqrtd, 2*a);
        printf("\n");
    }
    /* Otherwise just print it as sqrt(discriminant) */
    else
    {
        printf("(-%d + sqrt(%d)) / %d\n", b, discriminant, 2*a);
        printf("(-%d - sqrt(%d)) / %d\n", b, discriminant, 2*a);
    }

    return 0;
}

/*
 * Fairly dumb algorithm for computing
 * the square root of an integer.
 * Returns the smallest integer x such
 * that x*x >= y. If y is square then this
 * will be it's square root. Otherwise
 * it is the square root rounded up.
 */
int isqrt(int y)
{
    int x = 0;
    while(x*x < y)
    {
        x++;
    }
    return x;
}

void print_rational(int num, int denom)
{
    if(num % denom == 0)
    {
        printf("%d", num / denom);
    }
    else
    {
        printf("%d/%d", num, denom);
    }
}

void print_quadratic(int a, int b, int c)
{
    /* For -1 we just use a minus sign */
    if(a == -1)
    {
        printf("-");
    }
    /* Don't print coefficient if it's just 1 */
    else if(a != 1)
    {
        printf("%d", a);
    }
    printf("x^2");
    /* Only print second term if non-zero */
    if(b != 0)
    {
        if(b > 1)
        {
            printf(" + %d", b);
        }
        else if(b < 0)
        {
            // b < 0
            // This ensures a space after - sign
            printf(" - %d", -b);
        }
        else
        {
            // We get here if b == 1
            printf(" + ");
        }
        printf("x");
    }
    /* Only print constant if non-zero */
    if(c != 0)
    {
        if(c > 0)
        {
            printf(" + %d", c);
        }
        else
        {
            printf(" - %d", -c);
        }
    }
}
