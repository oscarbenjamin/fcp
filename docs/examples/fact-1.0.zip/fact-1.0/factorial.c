/* factorial.c */

/* Not needed in this example but usually X.c imports X.h */
#include "factorial.h"

/* Function definition */
int factorial(int n)
{
  int nfact = 1;
  while(n) {
    nfact *= n;
    n--;
  }
  return nfact;
}
