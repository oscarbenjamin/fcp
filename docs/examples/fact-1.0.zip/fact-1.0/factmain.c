/*
 * factmain.c
 *
 * Main code file for the func program.
 */

#include <stdio.h>
#include <stdlib.h>

/* Including factorial.h makes the factorial function available */
#include "factorial.h"

int main(int argc, char *argv[])
{
  /* Get the checking out the way first */
  if(argc != 2) {
    fprintf(stderr, "Usage: ./func.exe N\n");
    return 1;
  }
  /* We know argc == 2 so argv[1] exists */
  char *nstr = argv[1];
  int n = atoi(nstr);

  /* Note atoi returns 0 for error */
  if(n <= 0) { // More checking needed for e.g. "123asd"
    fprintf(stderr, "N should be a positive integer\n");
  }

  printf("factorial(%d) = %d\n", n, factorial(n));
  return 0;
}
