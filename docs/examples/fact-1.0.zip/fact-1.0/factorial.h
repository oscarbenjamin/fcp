/* factorial.h */

/* Function declaration */
int factorial(int n);
